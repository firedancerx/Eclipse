package com.allmycode.flags;


public class FlagsDemoActivity4 extends MyActivity {

}