package com.allmycode.flags;

public class FlagsDemoActivity2 extends MyActivity {

}