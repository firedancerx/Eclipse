package com.allmycode.flags;

public class FlagsDemoActivity3 extends MyActivity {

}