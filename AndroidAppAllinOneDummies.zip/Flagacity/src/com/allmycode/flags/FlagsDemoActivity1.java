package com.allmycode.flags;


public class FlagsDemoActivity1 extends MyActivity {

}