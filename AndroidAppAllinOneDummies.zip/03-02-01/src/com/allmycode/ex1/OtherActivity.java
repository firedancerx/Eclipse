package com.allmycode.ex1;

import android.app.Activity;
import android.os.Bundle;

public class OtherActivity extends Activity {
  
  @Override
  public void onCreate(Bundle savedInstanceState) {
      super.onCreate(savedInstanceState);
      setContentView(R.layout.other);
  }
}
