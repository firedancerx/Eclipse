package com.allmycode.screen;

import android.app.Activity;
import android.os.Bundle;

public class ScreenActivity extends Activity {

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);
  }
}