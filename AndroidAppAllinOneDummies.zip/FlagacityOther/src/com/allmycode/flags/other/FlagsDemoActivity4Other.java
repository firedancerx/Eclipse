package com.allmycode.flags.other;


public class FlagsDemoActivity4Other extends MyActivityOther {

}