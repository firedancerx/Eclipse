package com.allmycode.flags.other;

public class FlagsDemoActivity2Other extends MyActivityOther {

}