package com.allmycode.flags.other;

public class FlagsDemoActivity3Other extends MyActivityOther {

}