package com.allmycode.flags.other;


public class FlagsDemoActivity1Other extends MyActivityOther {

}